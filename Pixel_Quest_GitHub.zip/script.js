const data=[
 {name:"Aria",cat:"heroes",icon:"🧙‍♀️",desc:"Maga de energía. Ideal para empezar la aventura.",power:85},
 {name:"Rex",cat:"heroes",icon:"🛡️",desc:"Guerrero resistente que aguanta muchos golpes.",power:72},
 {name:"Luna",cat:"heroes",icon:"🏹",desc:"Arquera rápida con ataques a distancia.",power:80},
 {name:"Espada Solar",cat:"items",icon:"⚔️",desc:"Una espada especial que aumenta el ataque.",power:30},
 {name:"Poción",cat:"items",icon:"🧪",desc:"Recupera vida durante una batalla.",power:25},
 {name:"Cristal Azul",cat:"items",icon:"💎",desc:"Objeto raro que vale muchas monedas.",power:50},
 {name:"Dragón",cat:"enemies",icon:"🐉",desc:"Enemigo poderoso. Cuidado con su ataque.",power:92},
 {name:"Slime",cat:"enemies",icon:"🟢",desc:"Pequeño enemigo que aparece en los primeros niveles.",power:35},
 {name:"Gólem",cat:"enemies",icon:"🗿",desc:"Lento, pero tiene muchísima fuerza.",power:75}
];
let state={hp:100,score:0,level:1,coins:20};
const $=id=>document.getElementById(id);
function render(){
 const q=$("search").value.toLowerCase().trim(), cat=$("category").value;
 const filtered=data.filter(x=>(cat==="all"||x.cat===cat)&&(x.name.toLowerCase().includes(q)||x.desc.toLowerCase().includes(q)));
 $("cards").innerHTML=filtered.map(x=>`<article class="card"><div class="icon">${x.icon}</div><h3>${x.name}</h3><p>${x.desc}</p><div class="meta"><span>${label(x.cat)}</span><span>⚡ ${x.power}</span></div><button class="small-btn choose" data-name="${x.name}">Elegir</button></article>`).join("")||"<p>No se encontraron resultados.</p>";
 document.querySelectorAll(".choose").forEach(b=>b.addEventListener("click",()=>choose(b.dataset.name)));
}
function label(c){return c==="heroes"?"HÉROE":c==="items"?"OBJETO":"ENEMIGO"}
function update(){ $("hp").textContent=state.hp; $("score").textContent=state.score; $("level").textContent=state.level; $("coins").textContent=state.coins; }
function msg(t){$("message").textContent=t}
function choose(name){let x=data.find(a=>a.name===name);msg(`Elegiste ${x.icon} ${x.name}. ¡Tiene poder ${x.power}!`); if(x.cat==="items"){state.coins+=5;msg(`✨ Encontraste ${x.name}. +5 monedas.`);update()}}
function battle(){
 const enemies=data.filter(x=>x.cat==="enemies"), e=enemies[Math.floor(Math.random()*enemies.length)];
 const roll=Math.floor(Math.random()*101);
 if(roll>=e.power){state.score+=100;state.coins+=10;msg(`🏆 ¡Ganaste contra ${e.name}! +100 puntos y +10 monedas.`)}
 else{state.hp=Math.max(0,state.hp-15);msg(`💥 ${e.name} te atacó. Perdiste 15 de vida.`);if(state.hp===0){msg("☠️ Te quedaste sin vida. Reiniciá la partida para volver a jugar.")}}
 if(state.score>=300)state.level=2;if(state.score>=700)state.level=3;
 update();
}
$("search").addEventListener("input",render);$("category").addEventListener("change",render);
$("battleBtn").addEventListener("click",battle);
$("startBtn").addEventListener("click",()=>{$("game").scrollIntoView({behavior:"smooth"});msg("🚀 ¡Arrancaste la aventura! Elegí un personaje o peleá.");});
$("resetBtn").addEventListener("click",()=>{state={hp:100,score:0,level:1,coins:20};$("search").value="";$("category").value="all";update();render();msg("🔄 Partida reiniciada.");});
$("darkBtn").addEventListener("click",()=>document.body.classList.toggle("light"));
render();update();
