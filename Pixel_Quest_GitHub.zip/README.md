# Pixel Quest 🎮

Proyecto escolar realizado con HTML, CSS y JavaScript.

## ¿De qué trata?

Pixel Quest es un pequeño juego web de aventura. El jugador puede elegir personajes, consultar objetos y enemigos, buscar contenido, filtrar por categoría y participar en batallas rápidas.

## Funcionalidades

- Personajes, objetos y enemigos.
- Buscador.
- Filtro por categorías.
- Sistema de puntos, vida, nivel y monedas.
- Batallas aleatorias.
- Reinicio de partida.
- Modo claro/oscuro.
- Diseño responsive para computadora y celular.

## Tecnologías

- HTML: estructura.
- CSS: diseño y adaptación a distintos tamaños de pantalla.
- JavaScript: interacción y lógica del juego.

## Uso de IA

Se utilizó Inteligencia Artificial como ayuda durante el desarrollo para generar y mejorar partes del código, proponer ideas de diseño y detectar posibles errores. El código fue revisado para poder comprender cómo funciona.

## Cómo jugar

1. Abrir `index.html`.
2. Elegir un personaje u objeto.
3. Usar el buscador y las categorías.
4. Presionar **PELEAR** para comenzar una batalla.
5. Conseguir puntos y monedas y subir de nivel.
